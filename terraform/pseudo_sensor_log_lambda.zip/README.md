## test-lambda
test-lambda_API(count, interval 입력) → test-lambda(입력 데이터 결정 및 전달) → Kinesis_API(데이터 받아서 Kinesis로 전달)

테스트 방법
- POST 요청
- test-lambda_API의 Endpoint : https://xi06z4kg0d.execute-api.ap-northeast-2.amazonaws.com
- json body : count(요청 횟수), interval(요청 시간 간격, 초)
